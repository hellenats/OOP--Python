from project.car import Car
from project.sports_car import SportsCar
from project.vehicle import Vehicle


car1 = SportsCar()
print(car1.move())
print(car1.drive())
print(car1.race())
a=1